/* ==========================================================================
   SAVEST-HRIS User Manual — Content Data
   Structured content for every module and function in the system.
   Rendered by app.js. Screenshots live in assets/screenshots/.
   Each module and function carries its own `faq` array — questions are
   drawn only from that page's own content, never generic boilerplate.
   ========================================================================== */

const MANUAL_DATA = {
  appName: "SAVEST-HR",
  tagline: "User Manual",
  version: "1.0",

  // FAQ shown on the Home page — grounded only in what the Home page itself says.
  homeFaq: [
    {
      q: "How do I find a specific function in this manual?",
      a: "Browse by module using the cards below or the sidebar, or jump straight to a function with the “Search the whole manual” bar at the top of the page."
    },
    {
      q: "How many modules does SAVEST-HRIS have, and what do they cover?",
      a: "Five: Dashboard, Branches, Employees, Attendance Management, and System Settings — each card below shows how many functions it contains."
    },
    {
      q: "Can I save this manual for offline reading?",
      a: "Yes — open any page and click Export to PDF in the top-right corner to download a print-ready copy of that page."
    }
  ],

  modules: [
    // ============================================================ DASHBOARD
    {
      id: "dashboard",
      title: "Dashboard",
      icon: "home",
      intro: "Your landing page after signing in — a quick, real-time snapshot of the whole HRIS.",
      faq: [
        {
          q: "What's the difference between the Dashboard and the other modules?",
          a: "The Dashboard only summarizes data that already lives in Employees, Attendance Management, and System Settings — it's a snapshot, not an editing screen."
        },
        {
          q: "Do I need to sign in before seeing the Dashboard?",
          a: "Yes — Signing In is the required first step; you land on the Dashboard automatically right after a successful login."
        }
      ],
      functions: [
        {
          id: "signing-in",
          title: "Signing In",
          route: "/login",
          permission: "None — required before any other page can be accessed",
          screenshot: "login.png",
          description:
            "The Sign In page is the entry point to SAVEST-HRIS. Every user — regardless of role — starts here before reaching the Dashboard or any other module.",
          features: [
            "Username & Password sign-in — the standard login form.",
            "Show/hide password toggle (the eye icon) to confirm what you've typed.",
            "Login using Google — an alternate one-click sign-in for accounts linked to a Google identity.",
            "Inline error banner if the username or password is incorrect."
          ],
          steps: [
            "Open the SAVEST-HRIS URL in your browser — you land on the Sign In page automatically if you aren't already logged in.",
            "Enter your Username and Password.",
            "Click the eye icon next to the password field if you want to double-check what you typed.",
            "Click SIGN IN.",
            "Alternatively, click “Login using Google” to sign in with a linked Google account instead of a username/password.",
            "On success you are redirected straight to the Dashboard."
          ],
          tips: [
            "If sign-in fails, the page reloads with a red error banner stating whether the username or the password was incorrect.",
            "An account with no privileges assigned to its User Type will be signed out immediately as “Unauthorized Account” — contact an administrator to have a role assigned under System Settings → User Type & Permissions."
          ],
          faq: [
            {
              q: "What happens if I enter the wrong username or password?",
              a: "The page reloads with a red error banner that specifically tells you whether the username or the password was incorrect."
            },
            {
              q: "I signed in but got logged out immediately with “Unauthorized Account” — why?",
              a: "Your account's User Type has no privileges assigned yet. An administrator needs to grant it at least one privilege under System Settings → User Type & Permissions."
            },
            {
              q: "Can I sign in with Google instead of a username and password?",
              a: "Yes, via the “Login using Google” button — but only if your account was linked to a Google identity beforehand."
            }
          ]
        },
        {
          id: "overview",
          title: "Dashboard Overview",
          route: "/system/dashboard",
          permission: "None — visible to every signed-in user",
          screenshot: "dashboard.png",
          description:
            "The Dashboard is the first screen you see after signing in. It gives HR staff and administrators an at-a-glance view of the organization's headcount and the day's notable events, without needing to open any other module.",
          features: [
            "Active Roster Count — total number of currently active employees.",
            "Inactive / Archived Records — employees marked resigned, terminated, or archived.",
            "Today's Birthday List — employees celebrating a birthday today.",
            "Today's Work Anniversary List — employees reaching a service milestone today.",
            "System Logs feed — a live, chronological trail of recent actions taken in the system (logins, record updates, etc.)."
          ],
          steps: [
            "Sign in with your username and password (or Google account) from the login page.",
            "You are redirected automatically to the Dashboard.",
            "Review the roster counts and today's birthday/anniversary cards for quick people-moments worth acknowledging.",
            "Scroll the System Logs panel to see the most recent activity across the system.",
            "Use the sidebar on the left to jump into any module."
          ],
          tips: [
            "The System Logs panel only shows entries if your account has the “View System Logs” permission; otherwise the panel may appear empty.",
            "Roster counts update automatically each time an employee record is added, archived, or restored."
          ],
          faq: [
            {
              q: "Why is the System Logs panel empty on my Dashboard?",
              a: "That panel only shows entries if your account has the “View System Logs” permission — otherwise it appears empty."
            },
            {
              q: "How often do the Active Roster Count and Inactive/Archived Records update?",
              a: "Automatically, every time an employee record is added, archived, or restored — there's no manual refresh needed."
            },
            {
              q: "Where do the Today's Birthday and Work Anniversary lists come from?",
              a: "They're pulled live from employee records for whoever has a birthday or service milestone falling on the current day."
            }
          ]
        }
      ]
    },

    // =============================================================EMPLOYEES
    {
      id: "employees",
      title: "Employees",
      icon: "users",
      intro: "The core HR module: onboarding, employee records, positions, salary grades, employment status, and weekly work schedules.",
      faq: [
        {
          q: "Where do I start when onboarding a new hire?",
          a: "Employee Registration — it captures personal details, IDs, address, background, and the initial branch/position assignment in one form."
        },
        {
          q: "Where do I find an employee's salary, position, or status history?",
          a: "Open List of Employees, click the ⋮ actions menu on their row, and choose Salary Grade Movement, Position Movement, or Employment Status Movement."
        }
      ],
      functions: [
        {
          id: "registration",
          title: "Employee Registration",
          route: "/employee/registration_form",
          permission: "ADD NEW EMPLOYEE",
          screenshot: "employee-registration.png",
          description:
            "A comprehensive onboarding form used to create a brand-new employee record. It captures personal details, government IDs, address, family background, educational and work history, character references, and initial employment assignment (branch, position, date hired) in one submission.",
          features: [
            "Personal Information — name, gender, date/place of birth, civil status, religion, citizenship, height/weight.",
            "Contact Information — email, telephone, cellphone, emergency contact person.",
            "Government IDs — SSS, TIN, PhilHealth, PAG-IBIG, National ID, Driver's License, Biometric ID.",
            "Address — province, city/municipality, barangay, street.",
            "Family Background — father's/mother's name, spouse details, children.",
            "Educational Background — school, course/major, year graduated (supports multiple entries).",
            "Work Experience — previous company, position, salary, date started/ended (supports multiple entries).",
            "Character References — name, company, position, contact number.",
            "Employment Assignment — employee ID, date employed, account status, branch, and position."
          ],
          steps: [
            "Go to Employees → Employee Registration in the sidebar.",
            "Complete each section of the form, starting with Personal Information.",
            "Add Educational Background and Work Experience rows as needed using the “add row” controls in those sections.",
            "Fill in the Employment Assignment section — this determines the employee's branch and position going forward.",
            "Review all required fields (marked with a red asterisk) and click Submit / Save to create the record.",
            "The new employee will now appear in List of Employees and become selectable in schedules, movements, and other modules."
          ],
          tips: [
            "Required fields are marked with a red asterisk — the form will not submit until they're filled in.",
            "Have the employee's 201-file documents on hand before starting; several sections mirror a standard PDS (Personal Data Sheet)."
          ],
          faq: [
            {
              q: "What happens if I skip a required field?",
              a: "The form will not submit — required fields are marked with a red asterisk and must be filled in first."
            },
            {
              q: "Can I add more than one school or previous employer?",
              a: "Yes — the Educational Background and Work Experience sections both support multiple entries using their “add row” controls."
            },
            {
              q: "What happens right after I submit the registration form?",
              a: "The new employee immediately appears in List of Employees and becomes selectable in schedules, movements, and other modules."
            }
          ]
        },
        {
          id: "employee-list",
          title: "List of Employees",
          route: "/employee/employee_list",
          permission: "VIEW LIST OF EMPLOYEES",
          screenshot: "employee-list.png",
          description:
            "The master directory of all registered employees, with filters and a quick per-row action menu that opens into every other employee-centric function in the system.",
          features: [
            "Filter the list by Branch, Position, Employment Status, and Date Employed.",
            "Quick filter search box to find an employee by name.",
            "Per-employee actions menu (⋮): View Profile, Edit Info, Weekly Schedule, Salary Grade Movement, Position Movement, and Employment Status Movement.",
            "Pagination and adjustable page size."
          ],
          steps: [
            "Go to Employees → List of Employees.",
            "Use the Branch, Position, Employment Status, or Date Employed filters to narrow the list, or type in Quick Filter to search by name.",
            "Click the ⋮ actions icon on an employee's row to reveal the available actions for that employee.",
            "Choose View Profile to see the full read-only record, or Edit to open the editable form.",
            "Choose Weekly Schedule, Salary Grade Movement, Position Movement, or Employment Status Movement to manage that employee's history in the respective sub-function."
          ],
          tips: [
            "This page is the hub of the Employees module — most other employee functions are reached from its row actions rather than the sidebar."
          ],
          faq: [
            {
              q: "How do I open an employee's salary or position history from here?",
              a: "Click the ⋮ actions icon on their row and choose Salary Grade Movement or Position Movement."
            },
            {
              q: "Can I narrow the list down before searching?",
              a: "Yes — use the Branch, Position, Employment Status, or Date Employed filters, or type a name into the Quick Filter box."
            },
            {
              q: "Is this the only place to reach an employee's Weekly Schedule or Edit form?",
              a: "It's the main hub for it — this page is where most other employee functions are reached from, via each row's ⋮ actions menu."
            }
          ]
        },
        {
          id: "employee-profile",
          title: "Employee Profile (View)",
          route: "/employee/employee_profile/{employee_id}",
          permission: "VIEW LIST OF EMPLOYEES",
          screenshot: "employee-profile.png",
          description:
            "A read-only, full-detail view of a single employee's 201-file — personal information, contact details, government IDs, employment assignment, and history — opened from the List of Employees row action menu.",
          steps: [
            "From List of Employees, click the ⋮ menu on the desired employee and select View Profile.",
            "Review the employee's complete record across all sections.",
            "Use the profile picture uploader (if permitted) to update the employee's photo directly from this screen.",
            "Use the browser Back button or the breadcrumb to return to the list."
          ],
          faq: [
            {
              q: "Can I edit the employee's information from this Profile view?",
              a: "No — this page is read-only. Use Edit Info from the List of Employees ⋮ menu instead."
            },
            {
              q: "Can I update the employee's photo from this page?",
              a: "Yes, if you have permission — the profile picture uploader is available directly on this screen."
            }
          ]
        },
        {
          id: "employee-edit",
          title: "Edit Employee",
          route: "/employee/employee_edit/{employee_id}",
          permission: "UPDATE EMPLOYEE INFO",
          screenshot: "employee-edit.png",
          description:
            "An editable version of the employee record, mirroring the Employee Registration form, used to correct or update any previously saved information.",
          steps: [
            "From List of Employees, click the ⋮ menu on the desired employee and select Edit.",
            "Update any of the personal, contact, government ID, address, family, education, or work-experience fields.",
            "Click Update / Save to persist the changes.",
            "Changes are reflected immediately in the List of Employees and the employee's Profile view."
          ],
          tips: [
            "Employment status and employee number changes are tracked separately — use Employment Status Movement to log a formal status change with an effective date rather than editing the field directly here."
          ],
          faq: [
            {
              q: "Does changing Employment Status here create a dated history record?",
              a: "No — use Employment Status Movement instead to log a formal, dated status change; this form only edits the current saved fields."
            },
            {
              q: "Where do I see my changes after saving?",
              a: "Immediately in both List of Employees and that employee's Profile view."
            }
          ]
        },
        {
          id: "birthdays",
          title: "Upcoming Birthdays",
          route: "/employee/upcoming_birthdays",
          permission: "VIEW UPCOMING BIRTHDAYS",
          screenshot: "upcoming-birthdays.png",
          description:
            "A forward-looking list of employees whose birthdays are coming up, so HR can plan greetings, recognition, or celebrations in advance.",
          steps: [
            "Go to Employees → Upcoming Birthdays.",
            "Browse the list, sorted by the nearest upcoming date.",
            "Cross-reference with Branch if you want to coordinate a per-branch celebration."
          ],
          faq: [
            {
              q: "How is the Upcoming Birthdays list ordered?",
              a: "By the nearest upcoming date first."
            },
            {
              q: "Can I see birthdays for just one branch?",
              a: "Cross-reference the list with the Branch column if you want to coordinate a per-branch celebration."
            }
          ]
        },
        {
          id: "anniversaries",
          title: "Upcoming Work Anniversaries",
          route: "/employee/work_anniversarries",
          permission: "VIEW UPCOMING WORK ANNIVERSARIES",
          screenshot: "work-anniversaries.png",
          description:
            "Lists employees who are about to reach a work anniversary milestone (e.g. 1 year, 5 years of service), based on their Date Employed.",
          steps: [
            "Go to Employees → Upcoming Work Anniversaries.",
            "Review the list of employees and how many years of service each is about to complete.",
            "Use this list for service awards, loyalty bonuses, or regularization checks."
          ],
          faq: [
            {
              q: "What is this list calculated from?",
              a: "Each employee's Date Employed field, compared against today's date to find upcoming service milestones."
            },
            {
              q: "What is this page typically used for?",
              a: "Planning service awards, loyalty bonuses, or regularization checks ahead of the milestone date."
            }
          ]
        },
        {
          id: "salary-grade",
          title: "Salary Grade",
          route: "/salary-grades",
          permission: "VIEW SALARY GRADE · ADD NEW SALARY GRADE · UPDATE SALARY GRADE",
          screenshot: "salary-grades.png",
          modalScreenshot: "salary-grades-add-modal.png",
          modalLabel: "Add Salary Grade dialog",
          description:
            "Defines the organization's salary structure — each grade level and step combination carries a Basic Salary, Daily Rate, and Hourly Rate that can later be assigned to employees through Salary Grade Movement.",
          fields: [
            { name: "Grade Level", description: "The numeric salary grade (e.g. 1, 2, 3…). Required." },
            { name: "Step", description: "The increment step within that grade level. Required." },
            { name: "Basic Salary", description: "The monthly basic salary for this grade/step. Required." },
            { name: "Daily Rate", description: "The computed or fixed daily rate. Required." },
            { name: "Hourly Rate", description: "The computed or fixed hourly rate. Required." },
            { name: "Active", description: "Whether this grade/step is currently usable when assigning employees." }
          ],
          steps: [
            "Go to Employees → Salary Grade.",
            "Click “Add” to open the Salary Grade dialog.",
            "Enter the Grade Level, Step, Basic Salary, Daily Rate, and Hourly Rate.",
            "Leave Active checked and click Save.",
            "To adjust rates later, use the row's edit action — this does not retroactively change movements already recorded for employees."
          ],
          faq: [
            {
              q: "How do I actually assign a salary grade to an employee?",
              a: "Grades defined here are later assigned to employees through Salary Grade Movement, reached from that employee's row in List of Employees."
            },
            {
              q: "If I edit a grade's rate later, does it change employees' past records?",
              a: "No — editing a grade/step here does not retroactively change movements already recorded for employees."
            },
            {
              q: "What rates does each grade/step carry?",
              a: "A Basic Salary, a Daily Rate, and an Hourly Rate, all required when creating the grade."
            }
          ]
        },
        {
          id: "company-positions",
          title: "Company Positions",
          route: "/positions/company_positions",
          permission: "VIEW COMPANY POSITIONS · EDIT COMPANY POSITIONS · RESTORE AND ARCHIVE COMPANY POSITION",
          screenshot: "company-positions.png",
          modalScreenshot: "company-positions-add-modal.png",
          modalLabel: "Add Position dialog",
          description:
            "The catalog of job titles/positions available in the organization (e.g. HR Manager, HR Assistant Manager). Each position also shows how many employees currently hold it.",
          fields: [
            { name: "Position Name", description: "The job title, e.g. “HR Manager”. Required." }
          ],
          steps: [
            "Go to Employees → Company Positions.",
            "Optionally filter the list by Status (active/archived).",
            "Click “Add” and enter the Position Name, then Save.",
            "Use the row's edit action to rename a position.",
            "Use the archive action to retire a position without deleting its historical usage, or restore a previously archived one."
          ],
          tips: [
            "Archiving a position hides it from new-assignment dropdowns but keeps it visible for employees already holding it."
          ],
          faq: [
            {
              q: "What's the difference between archiving and deleting a position?",
              a: "Archiving hides the position from new-assignment dropdowns but keeps it visible for employees already holding it — there's no separate delete action, just archive and restore."
            },
            {
              q: "Can I tell how many employees hold a given position?",
              a: "Yes — the list on this page shows how many employees currently hold each position."
            }
          ]
        },
        {
          id: "employment-status",
          title: "Employment Status",
          route: "/employment_status/load",
          permission: "VIEW EMPLOYMENT STATUS · ADD NEW EMPLOYMENT STATUS · UPDATE EMPLOYMENT STATUS",
          screenshot: "employment-status.png",
          modalScreenshot: "employment-status-add-modal.png",
          modalLabel: "Add Employment Status dialog",
          description:
            "Maintains the set of employment status labels used across the system (e.g. Permanent, Probationary, Resigned) and shows how many employees currently carry each status.",
          fields: [
            { name: "Employment Status", description: "The label text, e.g. “Probationary”. Required." },
            { name: "Is Current Employee?", description: "Marks whether this status still counts the employee as an active member of the roster." },
            { name: "Is Visible?", description: "Controls whether the status appears in selection dropdowns." }
          ],
          steps: [
            "Go to Employees → Employment Status.",
            "Click “Add” to define a new status label.",
            "Set Is Current Employee and Is Visible according to how this status should behave, then Save.",
            "Use the row's edit action to rename or adjust an existing status."
          ],
          tips: [
            "To change one employee's status with a dated, auditable record, use Employment Status Movement from the employee's row action menu — this page only manages the master list of status labels."
          ],
          faq: [
            {
              q: "What does “Is Current Employee?” control?",
              a: "Whether this status still counts the employee as an active member of the roster (e.g. Resigned would typically be set to no)."
            },
            {
              q: "How do I change one specific employee's status with an effective date?",
              a: "Use Employment Status Movement from that employee's row action menu — this page only manages the master list of status labels, not individual assignments."
            }
          ]
        },
        {
          id: "weekly-schedules-list",
          title: "List of Weekly Schedules",
          route: "/ews/load_wsl",
          permission: "VIEW WEEKLY SCHEDULES",
          screenshot: "weekly-schedules-list.png",
          description:
            "Overview of weekly work-schedule assignments across employees, with access to bulk updates for applying the same schedule to many employees at once.",
          steps: [
            "Go to Employees → List of Weekly Schedules.",
            "Review current schedule assignments in the list.",
            "Use Bulk Update Schedules (linked from this page) to change the schedule for multiple employees in a single action.",
            "Open an individual employee's schedule from the List of Employees row actions for a per-employee view."
          ],
          faq: [
            {
              q: "How do I update schedules for many employees at once?",
              a: "Use Bulk Update Schedules, linked from this page, to change the schedule for multiple employees in a single action."
            },
            {
              q: "How do I see just one employee's schedule?",
              a: "Open it from that employee's row actions in List of Employees rather than from this overview page."
            }
          ]
        },
        {
          id: "employee-weekly-schedule",
          title: "Employee Weekly Schedule",
          route: "/ws/load_schedules/{employee_id}",
          permission: "VIEW EMPLOYEE WEEKLY SCHEDULES · UPDATE EMPLOYEE WEEKLY SCHEDULES",
          screenshot: "employee-weekly-schedule.png",
          description:
            "Shows and lets you update a single employee's weekly work schedule — which days they work and their shift times for each day of the week.",
          steps: [
            "From List of Employees, open the ⋮ menu on an employee and choose Weekly Schedule.",
            "Review the current day-by-day schedule.",
            "Update the shift times or rest days as needed and Save."
          ],
          faq: [
            {
              q: "What can I actually change on this page?",
              a: "The employee's shift times and rest days for each day of the week."
            },
            {
              q: "How do I reach one employee's Weekly Schedule page?",
              a: "From List of Employees, open the ⋮ menu on that employee and choose Weekly Schedule."
            }
          ]
        },
        {
          id: "salary-grade-movement",
          title: "Salary Grade Movement",
          route: "/salary-grade-movement/{employee_id}",
          permission: "VIEW SALARY GRADE · UPDATE SALARY GRADE",
          screenshot: "salary-grade-movement.png",
          description:
            "A dated history of an employee's salary grade assignments — records when a grade/step took effect and, if applicable, when it ended, so pay changes over time stay auditable.",
          steps: [
            "From List of Employees, open the ⋮ menu on an employee and choose Salary Grade Movement.",
            "Click “Add Salary Grade Movement” to record a new assignment.",
            "Select the salary grade/step, set the Effective Date (and End Date if it's already superseded), then Save.",
            "Use the row edit/delete icons to correct or remove a previously logged movement."
          ],
          faq: [
            {
              q: "When should I set an End Date on a movement entry?",
              a: "Once that salary grade assignment has been superseded by a newer one."
            },
            {
              q: "Can I fix a mistake in a movement I already logged?",
              a: "Yes — use the row's edit or delete icons to correct or remove a previously logged movement."
            }
          ]
        },
        {
          id: "position-movement",
          title: "Employee Position Movement",
          route: "/{employee_id}",
          permission: "EDIT COMPANY POSITIONS",
          screenshot: "employee-position-movement.png",
          description:
            "Tracks an employee's position/title history — promotions, transfers, or reassignments — each with an effective date range.",
          steps: [
            "From List of Employees, open the ⋮ menu on an employee and choose Position Movement.",
            "Click “Add Position Movement”.",
            "Choose the new Position and set the Effective Date (and End Date once superseded), then Save.",
            "Edit or delete existing entries using the row action icons."
          ],
          faq: [
            {
              q: "What kind of changes does this page track?",
              a: "An employee's position/title history — promotions, transfers, or reassignments — each with an effective date range."
            },
            {
              q: "How do I correct an existing position movement entry?",
              a: "Use the edit or delete row action icons on that entry."
            }
          ]
        },
        {
          id: "employment-status-movement",
          title: "Employment Status Movement",
          route: "/employment-status-movement/{employee_id}",
          permission: "UPDATE EMPLOYMENT STATUS",
          screenshot: "employment-status-movement.png",
          description:
            "Tracks the dated history of an employee's employment status changes — e.g. moving from Probationary to Permanent — independent from editing the raw field on the employee record.",
          steps: [
            "From List of Employees, open the ⋮ menu on an employee and choose Employment Status Movement.",
            "Click “Add” to log a new status change with its effective date.",
            "Select the Employment Status and set the date range, then Save.",
            "Edit or delete existing entries using the row action icons."
          ],
          faq: [
            {
              q: "How is this different from editing Employment Status on the Edit Employee page?",
              a: "This page keeps an independent, dated history of every status change (e.g. Probationary → Permanent), rather than just overwriting the current field."
            },
            {
              q: "Can I remove an incorrect status movement entry?",
              a: "Yes, using the edit or delete row action icons."
            }
          ]
        }
      ]
    },

    // ============================================================== BRANCHES
    {
      id: "branches",
      title: "Branches",
      icon: "share-2",
      intro: "Maintain the list of company branches / office locations used throughout the entire system.",
      faq: [
        {
          q: "Where else in the system are branches used?",
          a: "Every branch created here becomes selectable when assigning employees, filtering the employee list, restricting holidays to specific locations, and logging branch visits."
        },
        {
          q: "Who can add, update, or delete a branch?",
          a: "Only accounts whose User Type has the CREATE NEW BRANCH, UPDATE BRANCH, or DELETE BRANCH privilege respectively — VIEW BRANCHES is required just to see the page."
        }
      ],
      functions: [
        {
          id: "manage-branches",
          title: "Manage Branches",
          route: "/branches",
          permission: "VIEW BRANCHES · CREATE NEW BRANCH · UPDATE BRANCH · DELETE BRANCH",
          screenshot: "branches.png",
          modalScreenshot: "branches-add-modal.png",
          modalLabel: "Add Branch dialog",
          description:
            "Branches represent the physical offices or outlets your organization operates. Every branch created here becomes selectable elsewhere in the system — assigning employees, filtering the employee list, restricting holidays to specific branches, and logging branch visits.",
          fields: [
            { name: "Branch Code", description: "A short unique identifier for the branch (e.g. “Branch 02”). Required." },
            { name: "Branch Name", description: "The full, human-readable name of the branch/office. Required." },
            { name: "Address", description: "Street or area address of the branch. Optional." },
            { name: "Visible?", description: "Toggle to control whether the branch appears in dropdown filters system-wide." }
          ],
          steps: [
            "Open Branches from the sidebar (top-level module, no submenu).",
            "Click “Add Branch” in the upper-right corner of the page.",
            "Fill in the Branch Code, Branch Name, and optional Address.",
            "Leave “Visible” checked so the branch is selectable elsewhere in the system, then click Save.",
            "To edit a branch, use the action icon on its row, update the fields in the dialog, and click Save.",
            "To remove a branch, use the delete action icon on its row and confirm."
          ],
          tips: [
            "Deleting a branch does not automatically reassign employees already tied to it — reassign employees first if needed.",
            "Uncheck “Visible” instead of deleting when you want to retire a branch but keep its historical records intact."
          ],
          faq: [
            {
              q: "Should I delete a branch or just hide it?",
              a: "Uncheck “Visible” instead of deleting when you want to retire a branch but keep its historical records intact — deleting removes it outright."
            },
            {
              q: "What happens to employees assigned to a branch I delete?",
              a: "They are not automatically reassigned — reassign those employees to another branch first if needed."
            },
            {
              q: "Which fields are required when adding a branch?",
              a: "Branch Code and Branch Name are required; Address is optional."
            }
          ]
        }
      ]
    },

    // ==================================================ATTENDANCE MANAGEMENT
    {
      id: "attendance",
      title: "Attendance Management",
      icon: "clock",
      intro: "Timekeeping-related records: company-wide holidays, travel/seminar requests, branch visits, and employee suspensions.",
      faq: [
        {
          q: "What kinds of records live in this module?",
          a: "Company-wide holidays and non-working days, on-travel/seminar/training requests, branch visits, and employee suspensions."
        },
        {
          q: "Can these records be scoped to a specific branch?",
          a: "Holidays can be applied to all branches or specific ones, and Travel Requests / Branch Visits / Suspensions can all be filtered by branch on their list pages."
        }
      ],
      functions: [
        {
          id: "holidays",
          title: "Holidays & Non-Working Days",
          route: "/holidays",
          permission: "VIEW HOLIDAYS & NON-WORKING DAYS · ADD HOLIDAYS & NON-WORKING DAYS · UPDATE HOLIDAYS & NON-WORKING DAYS · DELETE HOLIDAYS & NON-WORKING DAYS",
          screenshot: "holidays.png",
          modalScreenshot: "holidays-add-modal.png",
          modalLabel: "New Holiday dialog",
          description:
            "The company-wide calendar of regular holidays, special non-working days, and other declared off-days, optionally scoped to specific branches.",
          fields: [
            { name: "Holiday / Day Name", description: "e.g. “Christmas Day”, “Typhoon Suspension”. Required." },
            { name: "Date", description: "The calendar date of the holiday. Required." },
            { name: "Type", description: "e.g. Regular Holiday, Special Non-Working Day. Required." },
            { name: "Coverage", description: "Whole Day or a Specific Time Range for partial-day suspensions." },
            { name: "Description", description: "Optional notes explaining the holiday." },
            { name: "Recurring annually", description: "Marks the holiday to repeat on the same date every year." },
            { name: "Applied to Branches", description: "Leave empty to apply to all branches, or select specific ones." }
          ],
          steps: [
            "Go to Attendance Management → Holidays & Non-Working Days.",
            "Click “Add Holiday”.",
            "Enter the Holiday/Day Name, Date, and Type.",
            "Choose Whole Day or Specific Time Range under Coverage.",
            "Optionally add a Description, mark it as Recurring annually, and select which branches it applies to.",
            "Click Save.",
            "Use the row action icons to edit or delete an existing holiday entry."
          ],
          faq: [
            {
              q: "Can a holiday apply to only some branches?",
              a: "Yes — leave Applied to Branches empty to apply it to all branches, or select specific ones to scope it."
            },
            {
              q: "What's the difference between Whole Day and Specific Time Range coverage?",
              a: "Whole Day covers the entire date, while Specific Time Range is for partial-day suspensions with defined start/end times."
            },
            {
              q: "Can I make a holiday repeat automatically every year?",
              a: "Yes — check “Recurring annually” when creating or editing it."
            }
          ]
        },
        {
          id: "travel-requests",
          title: "On-Travel / Seminar / Training",
          route: "/travel-requests",
          permission: "VIEW ON-TRAVEL & SEMINAR REQUESTS · ADD ON-TRAVEL & SEMINAR REQUESTS · UPDATE ON-TRAVEL & SEMINAR REQUESTS · DELETE ON-TRAVEL & SEMINAR REQUESTS",
          screenshot: "travel-requests.png",
          modalScreenshot: "travel-requests-add-modal.png",
          modalLabel: "New Request dialog",
          description:
            "Logs employees who are away from their regular post for an official on-travel assignment, seminar, or training, over a specific date range.",
          fields: [
            { name: "Employee(s)", description: "The employee(s) covered by this request. Required." },
            { name: "Type", description: "On-Travel, Seminar, or Training. Required." },
            { name: "Purpose / Title", description: "A short description of the reason for travel. Required." },
            { name: "Start Date / End Date", description: "The date range the employee is away. Required." },
            { name: "Notes", description: "Optional additional remarks." }
          ],
          steps: [
            "Go to Attendance Management → On-Travel / Seminar / Training.",
            "Use the Branch, Type, Purpose, or Date filters to narrow existing records.",
            "Click “Add” to log a new request.",
            "Select the employee(s), Type, Purpose, and the Start/End Date range, then Save.",
            "Use the row action icons to edit or delete a request."
          ],
          faq: [
            {
              q: "What types of requests can I log here?",
              a: "On-Travel, Seminar, or Training — chosen from the Type field when creating a request."
            },
            {
              q: "Can one request cover more than one employee?",
              a: "Yes — the Employee(s) field accepts more than one person for the same travel/seminar/training request."
            },
            {
              q: "Are Notes required when logging a request?",
              a: "No — Notes are optional; Employee(s), Type, Purpose, and the date range are the required fields."
            }
          ]
        },
        {
          id: "branch-visits",
          title: "Branch Visits",
          route: "/branch-visits",
          permission: "VIEW BRANCH VISITS · ADD BRANCH VISITS · UPDATE BRANCH VISITS · DELETE BRANCH VISITS",
          screenshot: "branch-visits.png",
          modalScreenshot: "branch-visits-add-modal.png",
          modalLabel: "New Branch Visit dialog",
          description:
            "Records employees who are temporarily working out of a branch other than their home branch — useful for auditing attendance across locations.",
          fields: [
            { name: "Employee(s)", description: "The employee(s) making the visit. Required." },
            { name: "Branch(es) Visited", description: "One or more destination branches. Required." },
            { name: "Purpose / Title", description: "Reason for the visit. Required." },
            { name: "Start Date / End Date", description: "The date range covering the visit. Required." },
            { name: "Notes", description: "Optional additional remarks." }
          ],
          steps: [
            "Go to Attendance Management → Branch Visits.",
            "Use the Employee Branch, Visited Branch, or Date filters to narrow existing records.",
            "Click “Add” to log a new visit.",
            "Select the employee(s), the branch(es) being visited, Purpose, and the Start/End Date range, then Save.",
            "Use the row action icons to edit or delete a visit record."
          ],
          faq: [
            {
              q: "Can one visit record cover more than one destination branch?",
              a: "Yes — Branch(es) Visited accepts one or more destination branches in the same record."
            },
            {
              q: "How do I filter existing visit records?",
              a: "Use the Employee Branch, Visited Branch, or Date filters above the list."
            }
          ]
        },
        {
          id: "suspensions",
          title: "Suspended Employees",
          route: "/suspensions",
          permission: "VIEW SUSPENDED EMPLOYEES · ADD SUSPENDED EMPLOYEES · UPDATE SUSPENDED EMPLOYEES · DELETE SUSPENDED EMPLOYEES",
          screenshot: "suspensions.png",
          modalScreenshot: "suspensions-add-modal.png",
          modalLabel: "New Suspension dialog",
          description:
            "Tracks employees who are under a work suspension, including the date range, total number of days, and the reason.",
          fields: [
            { name: "Employee", description: "The employee being suspended. Required." },
            { name: "Start Date / End Date", description: "The suspension period. Required." },
            { name: "Total Days", description: "Auto-computed or entered total number of suspension days." },
            { name: "Reason / Remarks", description: "Optional explanation for the suspension." }
          ],
          steps: [
            "Go to Attendance Management → Suspended Employees.",
            "Optionally filter existing records by Branch.",
            "Click “Add” to log a new suspension.",
            "Select the Employee, set the Start/End Date, and optionally add a Reason, then Save.",
            "Use the row action icons to edit or delete a suspension record."
          ],
          faq: [
            {
              q: "Do I need to calculate Total Days myself?",
              a: "No — Total Days can be auto-computed from the Start/End Date, or entered directly."
            },
            {
              q: "Is a Reason required when logging a suspension?",
              a: "No — Reason / Remarks is optional; Employee and the Start/End Date are required."
            }
          ]
        }
      ]
    },

    // =========================================================SYSTEM SETTINGS
    {
      id: "settings",
      title: "System Settings",
      icon: "settings",
      intro: "Administrative controls: user accounts, role-based permissions, system activity logs, and your own account profile.",
      faq: [
        {
          q: "Where do I control what a role is allowed to see or do?",
          a: "User Type & Permissions — every sidebar item and page action in the system is gated by the checkboxes defined there."
        },
        {
          q: "Where can I check what actions were recently taken in the system?",
          a: "System Logs — a chronological audit trail of logins, logouts, and record changes."
        }
      ],
      functions: [
        {
          id: "user-accounts",
          title: "User Accounts",
          route: "/system/user_accounts",
          permission: "VIEW USER ACCOUNTS",
          screenshot: "user-accounts.png",
          description:
            "Manage the login accounts that can access the HRIS — each account is tied to a User Type (role) that determines its permissions, and can be activated, deactivated, or have its password reset.",
          fields: [
            { name: "User Type", description: "The role assigned to the account, which determines its permissions." },
            { name: "Account Status", description: "Active or Inactive — inactive accounts cannot sign in." },
            { name: "New Password", description: "Optional field to force-reset the account's password from this screen." }
          ],
          steps: [
            "Go to System Settings → User Accounts.",
            "Use the User Type or Account Status filters to narrow the list, or use Quick Filter to search by name.",
            "Click the edit action on a user's row to open the account dialog.",
            "Change the User Type and/or Account Status as needed.",
            "Optionally enter a New Password to reset the account's credentials, then Save."
          ],
          tips: [
            "User accounts are created automatically when an employee is registered with system access; this page manages their role and status rather than creating brand-new accounts directly."
          ],
          faq: [
            {
              q: "How do I create a brand-new login account?",
              a: "You don't create one directly here — accounts are created automatically when an employee is registered with system access. This page manages an existing account's role, status, and password."
            },
            {
              q: "How do I reset someone's password?",
              a: "Open the edit action on their row and enter a value in the New Password field, then Save."
            },
            {
              q: "What happens if I set an account's status to Inactive?",
              a: "That account can no longer sign in until it's switched back to Active."
            }
          ]
        },
        {
          id: "user-permissions",
          title: "User Type & Permissions",
          route: "/system/user_permissions",
          permission: "VIEW USER TYPE & PERMISSIONS",
          screenshot: "user-permissions.png",
          modalScreenshot: "user-permissions-add-modal.png",
          modalLabel: "Create User Type dialog",
          description:
            "Defines the roles (User Types) available in the system — such as Administrator, HR Admin, and Employee — and the exact set of privileges each role is granted, grouped by module (Branches, Employee Management, Weekly Schedules, Salary Grade, and more).",
          fields: [
            { name: "User Type Name", description: "The role's display name, e.g. “HR Admin”. Required." },
            { name: "Badge Color", description: "A color used to visually tag the role throughout the UI." },
            { name: "Privileges & Access", description: "A checklist of individual permissions grouped by module — check every action this role should be allowed to perform." }
          ],
          steps: [
            "Go to System Settings → User Type & Permissions.",
            "Click “Create User Type” to define a new role.",
            "Enter the User Type Name and pick a Badge Color.",
            "Under Privileges & Access, check every permission this role should have (or use Select All within a section for full access to that module).",
            "Click Save to create the role.",
            "Use the row edit action on an existing role to adjust its name, color, or privileges."
          ],
          tips: [
            "Sidebar menu items and page actions throughout the whole system are shown or hidden based on these exact privilege checkboxes — if a menu item is missing for a user, check their role's privileges here first."
          ],
          faq: [
            {
              q: "How do I give a role full access to one entire module?",
              a: "Use the Select All link within that module's section of the Privileges & Access checklist."
            },
            {
              q: "Why is a sidebar item missing for one of my users?",
              a: "Check that user's role here first — sidebar items and page actions system-wide are shown or hidden based on the exact privilege checkboxes set for their User Type."
            },
            {
              q: "What is the Badge Color used for?",
              a: "It visually tags that role throughout the UI, so accounts of that User Type are easy to spot at a glance."
            }
          ]
        },
        {
          id: "system-logs",
          title: "System Logs",
          route: "/system/system_logs",
          permission: "VIEW SYSTEM LOGS",
          screenshot: "system-logs.png",
          description:
            "A chronological audit trail of actions performed across the system — logins, logouts, and record changes — each entry showing what happened, who performed it, and when.",
          steps: [
            "Go to System Settings → System Logs.",
            "Use the available filters to narrow logs by user or date, if provided.",
            "Review each entry's action description, the responsible user, and the timestamp.",
            "Use this page to investigate unexpected changes or confirm that an action (e.g. an employee update) was successfully recorded."
          ],
          faq: [
            {
              q: "What kinds of actions get recorded here?",
              a: "Logins, logouts, and record changes across the system."
            },
            {
              q: "What information does each log entry show?",
              a: "The action description, the user responsible, and the exact timestamp."
            }
          ]
        },
        {
          id: "profile",
          title: "My Profile",
          route: "/system/profile",
          permission: "None — available to every signed-in user",
          screenshot: "profile.png",
          description:
            "Your own account settings page — view your basic account details and change your password.",
          steps: [
            "Click your avatar in the top-right corner of any page and choose My Profile.",
            "Review your account details.",
            "To change your password, fill in the password fields and submit.",
            "Use Log Out from the same avatar menu when you're done."
          ],
          faq: [
            {
              q: "How do I get to My Profile?",
              a: "Click your avatar in the top-right corner of any page and choose My Profile."
            },
            {
              q: "How do I change my own password?",
              a: "On My Profile, fill in the password fields and submit."
            },
            {
              q: "How do I log out?",
              a: "Choose Log Out from the same avatar menu used to reach My Profile."
            }
          ]
        }
      ]
    }
  ]
};

// Flat lookup index built once at load time: "module-id/function-id" -> function object (+ moduleId/moduleTitle)
const MANUAL_INDEX = (() => {
  const idx = {};
  MANUAL_DATA.modules.forEach((mod) => {
    mod.functions.forEach((fn) => {
      idx[`${mod.id}/${fn.id}`] = { ...fn, moduleId: mod.id, moduleTitle: mod.title, moduleIcon: mod.icon };
    });
  });
  return idx;
})();
